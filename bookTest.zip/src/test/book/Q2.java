package test.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q2 {
	String URL ="jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q2() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con =DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void runSQL() {
		//도서명으로 검색하여 도서번호, 도서명, 가격을 Eclipse 콘솔창에 도서번호 순(오름차순)으로 출력하시오.
		Scanner scan = new Scanner(System.in);
		System.out.println("도서명을 입력하세요: ");
		String bookname =scan.next();
		
		String sql = "select bookid,bookname,price from book order by bookid asc";
		sql = "select bookid, bookname, price from book where bookname like '%" + bookname +"%'";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			
			while(rs.next()) {
				System.out.print("\t"+rs.getInt("bookid"));
				System.out.print("\t"+rs.getString("bookname"));
				System.out.println("\t"+rs.getInt("price"));
				
			}
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Q2 q2 = new Q2();
		q2.runSQL();
		

	}

}

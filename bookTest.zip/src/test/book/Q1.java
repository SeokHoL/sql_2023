package test.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q1 {
	String URL ="jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Q1() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con =DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void runSQL() {
		String sql = "select bookid,bookname from book order by bookid asc";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				System.out.print("\t"+rs.getInt("bookid"));
				System.out.println("\t"+rs.getString("bookname"));
				
			}
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Q1 q1 = new Q1();
		q1.runSQL();
		

	}

}
